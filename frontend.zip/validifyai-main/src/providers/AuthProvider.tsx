import { useEffect, type ReactNode } from "react";
import { useAuthStore } from "@/store/auth.store";
import { setAuthTokenGetter, setOnUnauthorized } from "@/lib/api";

/**
 * Wires the auth store into the API client so every request automatically
 * includes the bearer token, and a 401 response clears the session.
 *
 * Hydration is handled by zustand's persist middleware — no async bootstrap.
 */
export function AuthProvider({ children }: { children: ReactNode }) {
  const clear = useAuthStore((s) => s.clear);

  useEffect(() => {
    setAuthTokenGetter(() => useAuthStore.getState().token);
    setOnUnauthorized(() => clear());
  }, [clear]);

  return <>{children}</>;
}
