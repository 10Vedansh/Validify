import { type ReactNode } from "react";
import { Logo } from "@/components/Logo";
import { Link } from "@tanstack/react-router";

export function AuthLayout({
  title,
  subtitle,
  children,
  footer,
}: {
  title: string;
  subtitle: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  return (
    <div className="grid min-h-screen lg:grid-cols-[1fr_1.1fr]">
      {/* Form pane */}
      <div className="flex flex-col px-6 py-8 sm:px-12">
        <Logo />
        <div className="flex flex-1 items-center justify-center py-10">
          <div className="w-full max-w-sm">
            <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
            <p className="mt-1.5 text-sm text-muted-foreground">{subtitle}</p>
            <div className="mt-8">{children}</div>
            {footer && (
              <div className="mt-6 text-center text-sm text-muted-foreground">{footer}</div>
            )}
          </div>
        </div>
        <div className="text-xs text-muted-foreground">
          <Link to="/" className="transition-colors hover:text-foreground">
            ← Back to validify.app
          </Link>
        </div>
      </div>

      {/* Quote pane — calm, no halos */}
      <div className="relative hidden overflow-hidden border-l border-border bg-sidebar lg:flex">
        <div className="absolute inset-0 grid-pattern opacity-50 [mask-image:linear-gradient(to_bottom,black,transparent)]" />
        <div className="relative flex w-full flex-col justify-between p-12">
          <div className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
            Trusted by 8,200+ founders
          </div>
          <div className="max-w-md">
            <blockquote className="text-lg leading-snug tracking-tight text-foreground">
              “In four minutes Validify told us what three months of customer interviews didn't.
              We pivoted, raised, and shipped — all in the same quarter.”
            </blockquote>
            <div className="mt-6 flex items-center gap-3">
              <div className="grid h-8 w-8 place-items-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">
                SC
              </div>
              <div className="text-sm">
                <div className="font-medium">Sarah Chen</div>
                <div className="text-xs text-muted-foreground">Founder, Lumen AI</div>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-4 gap-6 text-xs text-muted-foreground">
            {["Acme", "Northwind", "Lumen", "Vertex"].map((n) => (
              <div key={n} className="font-medium">{n}</div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
