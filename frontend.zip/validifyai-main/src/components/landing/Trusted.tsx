import { trustedLogos } from "@/lib/mock";

export function Trusted() {
  return (
    <section className="border-y border-border/50 bg-card/30 py-10">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <p className="text-center text-xs uppercase tracking-widest text-muted-foreground">
          Trusted by founders from
        </p>
        <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-6 items-center">
          {trustedLogos.map((l) => (
            <div key={l} className="text-center text-muted-foreground/70 font-semibold tracking-wide">
              {l}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
