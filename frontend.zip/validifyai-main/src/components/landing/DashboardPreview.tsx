import { ResponsiveContainer, AreaChart, Area, XAxis, Tooltip, BarChart, Bar, CartesianGrid } from "recharts";
import { trendData } from "@/lib/mock";

export function DashboardPreview() {
  return (
    <section className="py-24 relative">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto text-center mb-12">
          <p className="text-sm text-primary font-medium">Dashboard</p>
          <h2 className="mt-3 text-3xl sm:text-5xl font-bold tracking-tight">A workspace that <span className="text-gradient">thinks like a VC</span></h2>
        </div>
        <div className="glass-strong rounded-3xl p-6 sm:p-8 shadow-card">
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 glass rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="text-xs text-muted-foreground">Industry trends</div>
                  <div className="text-lg font-semibold">Validation signals · last 7 months</div>
                </div>
                <div className="flex gap-2 text-xs">
                  {[["AI","chart-1"],["Fintech","chart-2"],["Climate","chart-3"],["Health","chart-4"]].map(([n,c]) => (
                    <span key={n} className="flex items-center gap-1.5"><span className={`h-2 w-2 rounded-full bg-${c}`}/>{n}</span>
                  ))}
                </div>
              </div>
              <div className="h-64">
                <ResponsiveContainer>
                  <AreaChart data={trendData}>
                    <defs>
                      <linearGradient id="a1" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="oklch(0.75 0.18 280)" stopOpacity={0.5}/><stop offset="100%" stopColor="oklch(0.75 0.18 280)" stopOpacity={0}/></linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.06)"/>
                    <XAxis dataKey="month" stroke="oklch(0.7 0.02 260)" fontSize={12}/>
                    <Tooltip contentStyle={{ background: "oklch(0.2 0.022 270)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12 }}/>
                    <Area type="monotone" dataKey="ai" stroke="oklch(0.75 0.18 280)" fill="url(#a1)" strokeWidth={2}/>
                    <Area type="monotone" dataKey="fintech" stroke="oklch(0.72 0.18 200)" fill="transparent" strokeWidth={2}/>
                    <Area type="monotone" dataKey="climate" stroke="oklch(0.78 0.17 150)" fill="transparent" strokeWidth={2}/>
                    <Area type="monotone" dataKey="health" stroke="oklch(0.80 0.18 70)" fill="transparent" strokeWidth={2}/>
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="space-y-4">
              {[
                { label: "Avg Validation", val: "78", delta: "+6%" },
                { label: "Active Ideas", val: "12", delta: "+2" },
                { label: "Investor Score", val: "A-", delta: "Seed" },
              ].map((s) => (
                <div key={s.label} className="glass rounded-2xl p-5">
                  <div className="text-xs text-muted-foreground">{s.label}</div>
                  <div className="mt-1 flex items-baseline justify-between">
                    <div className="text-3xl font-semibold">{s.val}</div>
                    <div className="text-xs text-chart-3">{s.delta}</div>
                  </div>
                </div>
              ))}
              <div className="glass rounded-2xl p-5 h-36">
                <div className="text-xs text-muted-foreground mb-2">Performance</div>
                <ResponsiveContainer>
                  <BarChart data={trendData.slice(-5)}>
                    <Bar dataKey="ai" fill="oklch(0.75 0.18 280)" radius={[6,6,0,0]}/>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
