import { testimonials } from "@/lib/mock";
import { Quote } from "lucide-react";

export function Testimonials() {
  return (
    <section className="py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto text-center mb-14">
          <p className="text-sm text-primary font-medium">Loved by founders</p>
          <h2 className="mt-3 text-3xl sm:text-5xl font-bold tracking-tight">Built for the next <span className="text-gradient">10,000 startups</span></h2>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          {testimonials.map((t) => (
            <div key={t.name} className="glass rounded-2xl p-6 hover:-translate-y-1 transition-transform">
              <Quote className="h-5 w-5 text-primary mb-3" />
              <p className="text-sm leading-relaxed">{t.quote}</p>
              <div className="mt-5 flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-gradient-primary grid place-items-center text-xs font-semibold text-primary-foreground">
                  {t.name.split(" ").map(n=>n[0]).join("")}
                </div>
                <div>
                  <div className="text-sm font-medium">{t.name}</div>
                  <div className="text-xs text-muted-foreground">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
