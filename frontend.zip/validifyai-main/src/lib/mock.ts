export const trustedLogos = ["Acme", "Northwind", "Lumen", "Vertex", "Pulse", "Quanta", "Nimbus", "Orbit"];

export const features = [
  { icon: "Brain", title: "AI SWOT Analysis", desc: "Instant strengths, weaknesses, opportunities & threats for any idea." },
  { icon: "LineChart", title: "Market Research", desc: "Live TAM/SAM/SOM estimates with trend signals across industries." },
  { icon: "Crosshair", title: "Competitor Detection", desc: "Find direct and lateral competitors before investors do." },
  { icon: "Gauge", title: "Investor Readiness", desc: "A 0–100 score modeled on real seed & Series A benchmarks." },
  { icon: "Presentation", title: "Pitch Deck Generator", desc: "From idea to a 10-slide investor-ready deck in seconds." },
  { icon: "Bot", title: "AI Co-Founder Chat", desc: "Strategize, stress-test, and unblock with a 24/7 thought partner." },
];

export const pricing = [
  { name: "Free", price: "$0", period: "/mo", desc: "Validate your first idea", features: ["3 validations / month", "Basic SWOT", "Community support"], cta: "Start free" },
  { name: "Pro", price: "$29", period: "/mo", desc: "For serious founders", features: ["Unlimited validations", "Investor readiness score", "Pitch deck generator", "AI co-founder chat", "Priority support"], cta: "Go Pro", featured: true },
  { name: "Enterprise", price: "Custom", period: "", desc: "For funds & accelerators", features: ["Team workspaces", "API access", "Custom benchmarks", "SAML SSO", "Dedicated CSM"], cta: "Contact sales" },
];

export const testimonials = [
  { name: "Sarah Chen", role: "Founder, Lumen AI", quote: "Validify saved us 3 months of pivoting. The investor score was scarily accurate." },
  { name: "Marcus Reed", role: "Partner, North Capital", quote: "We screen 200 decks a week with this. It's our unfair advantage." },
  { name: "Priya Natarajan", role: "CEO, Vertex Health", quote: "The SWOT alone is worth the subscription. Co-founder chat is a bonus." },
  { name: "Diego Alvarez", role: "Founder, Orbit Labs", quote: "Felt like having a McKinsey team on tap. Beautifully designed too." },
];

export const faqs = [
  { q: "How does Validify generate insights?", a: "We combine proprietary benchmark datasets with frontier LLMs to produce investor-grade analysis tailored to your idea." },
  { q: "Is my idea kept private?", a: "Always. Your data is encrypted at rest and never used to train external models." },
  { q: "Can I export my reports?", a: "Yes — every report exports to PDF, PPT, and shareable links on Pro and above." },
  { q: "Do you support teams?", a: "Enterprise includes workspaces, SSO, and role-based permissions." },
];

export const validations = [
  { name: "NeuroDesk", industry: "Productivity", score: 86, status: "Strong" },
  { name: "GreenLoop", industry: "Climate", score: 72, status: "Promising" },
  { name: "MediMatch", industry: "Healthtech", score: 91, status: "Excellent" },
  { name: "Lumefin", industry: "Fintech", score: 64, status: "Average" },
  { name: "Orbital CDN", industry: "DevTools", score: 78, status: "Strong" },
];

export const trendData = [
  { month: "Jan", ai: 42, climate: 30, fintech: 55, health: 38 },
  { month: "Feb", ai: 50, climate: 32, fintech: 52, health: 41 },
  { month: "Mar", ai: 61, climate: 36, fintech: 58, health: 44 },
  { month: "Apr", ai: 70, climate: 41, fintech: 60, health: 48 },
  { month: "May", ai: 82, climate: 47, fintech: 63, health: 52 },
  { month: "Jun", ai: 91, climate: 52, fintech: 65, health: 57 },
  { month: "Jul", ai: 96, climate: 58, fintech: 67, health: 61 },
];

export const industries = [
  { name: "AI / ML", value: 38 },
  { name: "Fintech", value: 22 },
  { name: "Climate", value: 16 },
  { name: "Healthtech", value: 14 },
  { name: "DevTools", value: 10 },
];

export const recommendations = [
  "Tighten ICP to design-led B2B SaaS teams under 200 employees.",
  "Add a usage-based tier — competitors monetize 31% better with hybrid pricing.",
  "Launch a developer-first changelog to build SEO moat early.",
  "Recruit a clinical advisor before fundraising — investors flagged this gap.",
];

export const chatHistory = [
  { id: "1", title: "Pricing for prosumer SaaS", time: "2h ago" },
  { id: "2", title: "GTM for vertical AI", time: "Yesterday" },
  { id: "3", title: "Cap table simulation", time: "3d ago" },
  { id: "4", title: "Cold email teardown", time: "1w ago" },
];

export const suggestedPrompts = [
  "Stress-test my pricing strategy",
  "Draft a 10-slide pitch deck outline",
  "Who are 5 lateral competitors I'm missing?",
  "Write a cold investor intro email",
];

export const swot = {
  strengths: ["Strong technical moat", "Founder–market fit", "Low CAC channel identified"],
  weaknesses: ["Unproven monetization", "Single-region team", "No design hire yet"],
  opportunities: ["Regulation tailwind in EU", "Emerging buyer persona", "Partnership with incumbents"],
  threats: ["Well-funded incumbent", "Platform risk on OpenAI", "Long enterprise sales cycle"],
};
