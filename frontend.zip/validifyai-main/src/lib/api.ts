import axios, { AxiosError, type InternalAxiosRequestConfig } from "axios";
import { API_URL } from "@/constants/config";
import type { ApiError } from "@/types/api";

/**
 * Centralized HTTP client.
 *
 * - Reads base URL from VITE_API_URL.
 * - Attaches bearer token from the auth store on every request.
 * - Normalizes errors to ApiError so UI code never deals with raw Axios shapes.
 */
export const api = axios.create({
  baseURL: API_URL,
  withCredentials: true,
  timeout: 20_000,
  headers: { "Content-Type": "application/json" },
});

// Token getter is wired by AuthProvider on boot so we avoid an import cycle.
let tokenGetter: () => string | null = () => null;
export const setAuthTokenGetter = (fn: () => string | null) => {
  tokenGetter = fn;
};

let onUnauthorized: (() => void) | null = null;
export const setOnUnauthorized = (fn: () => void) => {
  onUnauthorized = fn;
};

api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = tokenGetter();
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (error: AxiosError<{ message?: string; code?: string }>) => {
    if (error.response?.status === 401) onUnauthorized?.();

    const normalized: ApiError = {
      message:
        error.response?.data?.message ??
        error.message ??
        "Something went wrong. Please try again.",
      status: error.response?.status,
      code: error.response?.data?.code ?? error.code,
    };
    return Promise.reject(normalized);
  },
);
