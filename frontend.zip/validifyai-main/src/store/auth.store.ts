import { create } from "zustand";
import { persist } from "zustand/middleware";
import { AUTH_STORAGE_KEY } from "@/constants/config";
import type { AuthSession, User } from "@/types/user";

type AuthState = {
  user: User | null;
  token: string | null;
  status: "idle" | "authenticated" | "unauthenticated";
  setSession: (session: AuthSession | null) => void;
  setUser: (user: User) => void;
  clear: () => void;
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      status: "idle",
      setSession: (session) =>
        set(
          session
            ? { user: session.user, token: session.token, status: "authenticated" }
            : { user: null, token: null, status: "unauthenticated" },
        ),
      setUser: (user) => set({ user }),
      clear: () => set({ user: null, token: null, status: "unauthenticated" }),
    }),
    {
      name: AUTH_STORAGE_KEY,
      partialize: (s) => ({ user: s.user, token: s.token }),
    },
  ),
);
