import { api } from "@/lib/api";
import type { User } from "@/types/user";

const USE_MOCK = !import.meta.env.VITE_API_URL;

export const userService = {
  async update(patch: Partial<Pick<User, "name" | "avatarUrl">>): Promise<User> {
    if (USE_MOCK) {
      return {
        id: "u_001",
        email: "ada@validify.dev",
        name: patch.name ?? "Ada Lovelace",
        plan: "pro",
        createdAt: new Date().toISOString(),
        avatarUrl: patch.avatarUrl,
      };
    }
    const { data } = await api.patch<User>("/me", patch);
    return data;
  },
};
