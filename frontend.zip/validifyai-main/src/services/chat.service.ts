import { api } from "@/lib/api";
import type { ChatMessage, ChatThread } from "@/types/report";

const USE_MOCK = !import.meta.env.VITE_API_URL;

export const chatService = {
  async threads(): Promise<ChatThread[]> {
    if (USE_MOCK) return [];
    const { data } = await api.get<ChatThread[]>("/chat/threads");
    return data;
  },

  async messages(threadId: string): Promise<ChatMessage[]> {
    if (USE_MOCK) return [];
    const { data } = await api.get<ChatMessage[]>(`/chat/threads/${threadId}/messages`);
    return data;
  },

  /**
   * Streaming-ready send. Yields incremental chunks for the assistant reply.
   * Backend can swap this implementation for SSE / fetch streaming.
   */
  async *send(
    threadId: string,
    content: string,
    signal?: AbortSignal,
  ): AsyncGenerator<string, void, unknown> {
    if (USE_MOCK) {
      const reply =
        "Here's how I'd think about it:\n\n1. Isolate the most painful customer segment.\n2. Map willingness-to-pay against unit economics.\n3. Test a hybrid seat + usage model and instrument retention from day one.\n\nWant me to draft a one-page strategy memo?";
      for (const word of reply.split(/(\s+)/)) {
        if (signal?.aborted) return;
        await new Promise((r) => setTimeout(r, 18));
        yield word;
      }
      return;
    }
    // Real backend: fetch with streaming
    const res = await fetch(`${api.defaults.baseURL}/chat/threads/${threadId}/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content }),
      signal,
    });
    const reader = res.body?.getReader();
    if (!reader) return;
    const decoder = new TextDecoder();
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      yield decoder.decode(value, { stream: true });
    }
  },
};
