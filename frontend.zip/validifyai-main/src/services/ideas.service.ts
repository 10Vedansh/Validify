import { api } from "@/lib/api";
import type { Idea, IdeaDraft, Validation } from "@/types/startup";

const USE_MOCK = !import.meta.env.VITE_API_URL;

export const ideasService = {
  async list(): Promise<Idea[]> {
    if (USE_MOCK) return [];
    const { data } = await api.get<Idea[]>("/ideas");
    return data;
  },

  async create(draft: IdeaDraft): Promise<Idea> {
    if (USE_MOCK) {
      const now = new Date().toISOString();
      return { id: `idea_${Date.now()}`, createdAt: now, updatedAt: now, ...draft };
    }
    const { data } = await api.post<Idea>("/ideas", draft);
    return data;
  },

  async validate(ideaId: string): Promise<Validation> {
    if (USE_MOCK) {
      await new Promise((r) => setTimeout(r, 1200));
      return {
        id: `val_${Date.now()}`,
        ideaId,
        status: "complete",
        createdAt: new Date().toISOString(),
        score: { overall: 82, market: 86, team: 72, moat: 78, monetization: 64, traction: 58, risk: 70 },
      };
    }
    const { data } = await api.post<Validation>(`/ideas/${ideaId}/validate`);
    return data;
  },
};
