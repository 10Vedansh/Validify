import { api } from "@/lib/api";
import type { AuthSession, LoginPayload, RegisterPayload, User } from "@/types/user";

/**
 * Auth service.
 *
 * Mocked locally for now so the UI works end-to-end without a backend.
 * Replace each branch with the real api.post(...) call when the API is ready.
 */
const USE_MOCK = !import.meta.env.VITE_API_URL;

const mockUser = (overrides?: Partial<User>): User => ({
  id: "u_001",
  email: "ada@validify.dev",
  name: "Ada Lovelace",
  plan: "pro",
  createdAt: new Date().toISOString(),
  ...overrides,
});

export const authService = {
  async login(payload: LoginPayload): Promise<AuthSession> {
    if (USE_MOCK) {
      await new Promise((r) => setTimeout(r, 600));
      return { user: mockUser({ email: payload.email }), token: "mock.jwt.token" };
    }
    const { data } = await api.post<AuthSession>("/auth/login", payload);
    return data;
  },

  async register(payload: RegisterPayload): Promise<AuthSession> {
    if (USE_MOCK) {
      await new Promise((r) => setTimeout(r, 700));
      return { user: mockUser({ email: payload.email, name: payload.name }), token: "mock.jwt.token" };
    }
    const { data } = await api.post<AuthSession>("/auth/register", payload);
    return data;
  },

  async logout(): Promise<void> {
    if (USE_MOCK) return;
    await api.post("/auth/logout");
  },

  async me(): Promise<User> {
    if (USE_MOCK) return mockUser();
    const { data } = await api.get<User>("/auth/me");
    return data;
  },

  async requestPasswordReset(email: string): Promise<void> {
    if (USE_MOCK) {
      await new Promise((r) => setTimeout(r, 400));
      return;
    }
    await api.post("/auth/forgot-password", { email });
  },
};
