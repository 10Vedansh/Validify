import { api } from "@/lib/api";
import type { Report } from "@/types/report";

const USE_MOCK = !import.meta.env.VITE_API_URL;

export const reportsService = {
  async list(): Promise<Report[]> {
    if (USE_MOCK) return [];
    const { data } = await api.get<Report[]>("/reports");
    return data;
  },
  async get(id: string): Promise<Report | null> {
    if (USE_MOCK) return null;
    const { data } = await api.get<Report>(`/reports/${id}`);
    return data;
  },
  async exportPdf(id: string): Promise<Blob> {
    const { data } = await api.get(`/reports/${id}/export.pdf`, { responseType: "blob" });
    return data;
  },
};
