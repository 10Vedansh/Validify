export const APP_NAME = import.meta.env.VITE_APP_NAME ?? "Validify";
export const API_URL = import.meta.env.VITE_API_URL ?? "/api";
export const AUTH_STORAGE_KEY = "validify.auth";
export const THEME_STORAGE_KEY = "validify.theme";
