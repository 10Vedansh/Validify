import { createFileRoute } from "@tanstack/react-router";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Copy, KeyRound, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/dashboard/settings")({ component: Settings });

function Settings() {
  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-sm text-muted-foreground">Manage your profile, subscription, and security.</p>
      </div>

      <Tabs defaultValue="profile">
        <TabsList className="glass">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="billing">Subscription</TabsTrigger>
          <TabsTrigger value="api">API Keys</TabsTrigger>
          <TabsTrigger value="theme">Theme</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="mt-6 glass rounded-2xl p-6 space-y-5">
          <div className="flex items-center gap-4">
            <div className="h-16 w-16 rounded-full bg-gradient-primary grid place-items-center text-xl font-semibold text-primary-foreground">AL</div>
            <div>
              <Button variant="outline" size="sm" className="glass">Upload photo</Button>
              <p className="text-xs text-muted-foreground mt-2">PNG or JPG · max 2MB</p>
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-1.5"><Label>First name</Label><Input defaultValue="Ada"/></div>
            <div className="space-y-1.5"><Label>Last name</Label><Input defaultValue="Lovelace"/></div>
            <div className="space-y-1.5 sm:col-span-2"><Label>Email</Label><Input defaultValue="ada@validify.ai"/></div>
            <div className="space-y-1.5 sm:col-span-2"><Label>Bio</Label><Input defaultValue="Founder · ex-Stripe"/></div>
          </div>
          <Button className="bg-gradient-primary text-primary-foreground">Save changes</Button>
        </TabsContent>

        <TabsContent value="billing" className="mt-6 grid md:grid-cols-2 gap-4">
          <div className="glass rounded-2xl p-6">
            <div className="text-xs text-muted-foreground">Current plan</div>
            <div className="text-2xl font-semibold mt-1">Pro <Badge variant="outline" className="ml-2 border-primary/40 text-primary">Annual</Badge></div>
            <p className="text-sm text-muted-foreground mt-2">Renews on Jun 12, 2026 · $290/yr</p>
            <div className="mt-5 flex gap-2"><Button className="bg-gradient-primary text-primary-foreground">Upgrade</Button><Button variant="outline" className="glass">Manage</Button></div>
          </div>
          <div className="glass rounded-2xl p-6">
            <div className="font-semibold">Usage this month</div>
            {[["Validations","42 / ∞"],["AI tokens","1.2M / 3M"],["Deck exports","12 / 50"]].map(([l,v]) => (
              <div key={l} className="mt-3"><div className="flex justify-between text-sm"><span>{l}</span><span className="text-muted-foreground">{v}</span></div><div className="h-1.5 mt-1 rounded-full bg-secondary overflow-hidden"><div className="h-full bg-gradient-primary w-2/3"/></div></div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="api" className="mt-6 glass rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div><div className="font-semibold flex items-center gap-2"><KeyRound className="h-4 w-4"/>API keys</div><p className="text-sm text-muted-foreground">Use these to call the Validify API.</p></div>
            <Button className="bg-gradient-primary text-primary-foreground">Create key</Button>
          </div>
          {[
            { name: "Production", key: "vld_live_•••••••••••••••8a2c", date: "Created Jan 12" },
            { name: "Staging", key: "vld_test_•••••••••••••••71fe", date: "Created Mar 04" },
          ].map((k) => (
            <div key={k.name} className="flex items-center gap-3 p-3 rounded-xl glass">
              <div className="flex-1"><div className="text-sm font-medium">{k.name}</div><div className="text-xs text-muted-foreground">{k.key} · {k.date}</div></div>
              <Button size="icon" variant="ghost"><Copy className="h-4 w-4"/></Button>
              <Button size="icon" variant="ghost" className="text-destructive"><Trash2 className="h-4 w-4"/></Button>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="theme" className="mt-6 glass rounded-2xl p-6">
          <div className="font-semibold mb-3">Appearance</div>
          <div className="grid grid-cols-3 gap-3">
            {["Dark","Midnight","System"].map((t,i) => (
              <button key={t} className={`glass rounded-xl p-4 text-left ${i===0?"ring-1 ring-primary":""}`}>
                <div className="h-16 rounded-lg bg-gradient-primary opacity-80 mb-3"/>
                <div className="text-sm font-medium">{t}</div>
              </button>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="notifications" className="mt-6 glass rounded-2xl p-6 space-y-4">
          {["Weekly market digest","New competitor alerts","Investor signal changes","Product updates"].map((n) => (
            <div key={n} className="flex items-center justify-between"><div className="text-sm">{n}</div><Switch defaultChecked/></div>
          ))}
        </TabsContent>

        <TabsContent value="security" className="mt-6 glass rounded-2xl p-6 space-y-5">
          <div className="space-y-1.5"><Label>Current password</Label><Input type="password"/></div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-1.5"><Label>New password</Label><Input type="password"/></div>
            <div className="space-y-1.5"><Label>Confirm</Label><Input type="password"/></div>
          </div>
          <div className="flex items-center justify-between border-t border-border/60 pt-4">
            <div><div className="text-sm font-medium">Two-factor authentication</div><p className="text-xs text-muted-foreground">Add an extra layer of security to your account.</p></div>
            <Switch/>
          </div>
          <Button className="bg-gradient-primary text-primary-foreground">Update security</Button>
        </TabsContent>
      </Tabs>
    </div>
  );
}
