import { createFileRoute } from "@tanstack/react-router";
import { ResponsiveContainer, AreaChart, Area, LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { trendData, industries } from "@/lib/mock";
import { TrendingUp, Flame } from "lucide-react";

export const Route = createFileRoute("/dashboard/trends")({ component: Trends });

const heat = Array.from({ length: 7 }, (_, r) => Array.from({ length: 14 }, (_, c) => Math.round(Math.random()*100)));

function Trends() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Market Trends</h1>
        <p className="text-sm text-muted-foreground">Where capital, talent, and attention are flowing right now.</p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { l: "Hottest sector", v: "Vertical AI", d: "+38% MoM" },
          { l: "Avg seed round", v: "$3.4M", d: "+9%" },
          { l: "Time to Series A", v: "18mo", d: "−2mo" },
          { l: "Investor interest", v: "8.6/10", d: "All-time high" },
        ].map((s) => (
          <div key={s.l} className="glass rounded-2xl p-5">
            <div className="text-xs text-muted-foreground">{s.l}</div>
            <div className="mt-1 text-3xl font-semibold">{s.v}</div>
            <div className="text-xs text-chart-3 mt-1 inline-flex items-center gap-1"><TrendingUp className="h-3 w-3"/>{s.d}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="glass rounded-2xl p-5">
          <div className="font-semibold mb-3">Industry momentum</div>
          <div className="h-64">
            <ResponsiveContainer>
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.06)"/>
                <XAxis dataKey="month" stroke="oklch(0.7 0.02 260)" fontSize={12}/>
                <YAxis stroke="oklch(0.7 0.02 260)" fontSize={12}/>
                <Tooltip contentStyle={{ background: "oklch(0.2 0.022 270)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12 }}/>
                <Line type="monotone" dataKey="ai" stroke="oklch(0.75 0.18 280)" strokeWidth={2} dot={false}/>
                <Line type="monotone" dataKey="fintech" stroke="oklch(0.72 0.18 200)" strokeWidth={2} dot={false}/>
                <Line type="monotone" dataKey="climate" stroke="oklch(0.78 0.17 150)" strokeWidth={2} dot={false}/>
                <Line type="monotone" dataKey="health" stroke="oklch(0.80 0.18 70)" strokeWidth={2} dot={false}/>
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="glass rounded-2xl p-5">
          <div className="font-semibold mb-3">Funding by sector</div>
          <div className="h-64">
            <ResponsiveContainer>
              <BarChart data={industries}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.06)"/>
                <XAxis dataKey="name" stroke="oklch(0.7 0.02 260)" fontSize={11}/>
                <Tooltip contentStyle={{ background: "oklch(0.2 0.022 270)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12 }}/>
                <Bar dataKey="value" radius={[8,8,0,0]} fill="oklch(0.72 0.18 200)"/>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="glass rounded-2xl p-5">
        <div className="flex items-center gap-2 font-semibold mb-3"><Flame className="h-4 w-4 text-primary"/>Activity heatmap · last 14 weeks</div>
        <div className="overflow-x-auto">
          <div className="inline-grid gap-1" style={{ gridTemplateColumns: "repeat(14, 1.25rem)" }}>
            {heat.flat().map((v,i) => (
              <div key={i} className="h-5 w-5 rounded-sm" style={{ background: `oklch(0.75 0.18 280 / ${0.05 + (v/100)*0.85})` }}/>
            ))}
          </div>
        </div>
        <div className="flex items-center justify-between mt-3 text-xs text-muted-foreground">
          <span>Less</span>
          <div className="flex gap-1">{[0.1,0.3,0.5,0.7,0.9].map(o=><span key={o} className="h-3 w-3 rounded-sm" style={{background:`oklch(0.75 0.18 280 / ${o})`}}/>)}</div>
          <span>More</span>
        </div>
      </div>

      <div className="glass rounded-2xl p-5">
        <div className="font-semibold mb-3">Investor interest tracker</div>
        <div className="h-56">
          <ResponsiveContainer>
            <AreaChart data={trendData}>
              <defs><linearGradient id="t1" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="oklch(0.78 0.17 150)" stopOpacity={0.5}/><stop offset="100%" stopColor="oklch(0.78 0.17 150)" stopOpacity={0}/></linearGradient></defs>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.06)"/>
              <XAxis dataKey="month" stroke="oklch(0.7 0.02 260)" fontSize={12}/>
              <Tooltip contentStyle={{ background: "oklch(0.2 0.022 270)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12 }}/>
              <Area type="monotone" dataKey="climate" stroke="oklch(0.78 0.17 150)" fill="url(#t1)" strokeWidth={2}/>
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
