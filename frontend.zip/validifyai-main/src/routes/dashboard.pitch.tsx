import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Plus, Download, Share2, Presentation } from "lucide-react";

export const Route = createFileRoute("/dashboard/pitch")({ component: Pitch });

const decks = [
  { name: "NeuroDesk · Seed deck", updated: "2h ago", slides: 12 },
  { name: "GreenLoop · Pre-seed", updated: "Yesterday", slides: 10 },
  { name: "MediMatch · Series A", updated: "4d ago", slides: 16 },
];

function Pitch() {
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Pitch Decks</h1>
          <p className="text-sm text-muted-foreground">AI-generated, investor-ready in minutes.</p>
        </div>
        <Button className="bg-gradient-primary text-primary-foreground shadow-glow"><Plus className="mr-2 h-4 w-4"/>Generate deck</Button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {decks.map((d) => (
          <div key={d.name} className="glass rounded-2xl p-5 hover:-translate-y-1 transition-transform">
            <div className="relative aspect-video rounded-xl overflow-hidden bg-gradient-primary/30 grid place-items-center">
              <Presentation className="h-10 w-10 text-primary-foreground/80"/>
              <div className="absolute bottom-2 left-2 right-2 flex gap-1">
                {Array.from({length:d.slides}).map((_,i) => <div key={i} className="h-1 flex-1 rounded-full bg-background/40"/>)}
              </div>
            </div>
            <div className="mt-4 flex items-start justify-between gap-2">
              <div>
                <div className="font-medium">{d.name}</div>
                <div className="text-xs text-muted-foreground">{d.slides} slides · updated {d.updated}</div>
              </div>
            </div>
            <div className="mt-4 flex gap-2">
              <Button size="sm" variant="outline" className="glass flex-1"><Download className="mr-1.5 h-3.5 w-3.5"/>Export</Button>
              <Button size="sm" variant="outline" className="glass flex-1"><Share2 className="mr-1.5 h-3.5 w-3.5"/>Share</Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
