import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import { Upload, Sparkles, Loader2, ArrowRight, TrendingUp, Target, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/dashboard/validate")({ component: Validate });

function Validate() {
  const [name, setName] = useState("");
  const [problem, setProblem] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const score = Math.min(95, 40 + name.length * 2 + Math.min(40, problem.length / 4));

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => { setLoading(false); setDone(true); window.scrollTo({ top: 600, behavior: "smooth" }); }, 1500);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Validate a new idea</h1>
        <p className="text-sm text-muted-foreground">Fill in the brief — Validify will run a full investor-grade analysis.</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <form onSubmit={onSubmit} className="lg:col-span-2 glass rounded-2xl p-6 space-y-5">
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-1.5"><Label>Startup Name</Label><Input value={name} onChange={(e)=>setName(e.target.value)} placeholder="e.g. NeuroDesk"/></div>
            <div className="space-y-1.5"><Label>Industry</Label>
              <Select><SelectTrigger><SelectValue placeholder="Select industry"/></SelectTrigger>
                <SelectContent>{["AI / ML","Fintech","Healthtech","Climate","DevTools","Consumer"].map(i=><SelectItem key={i} value={i}>{i}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5"><Label>Problem Statement</Label>
            <Textarea value={problem} onChange={(e)=>setProblem(e.target.value)} rows={3} placeholder="What painful, frequent problem are you solving — and for whom?"/>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-1.5"><Label>Target Audience</Label><Input placeholder="e.g. PMs at Series A SaaS"/></div>
            <div className="space-y-1.5"><Label>Business Model</Label>
              <Select><SelectTrigger><SelectValue placeholder="Choose model"/></SelectTrigger>
                <SelectContent>{["SaaS","Marketplace","Transactional","Usage-based","Freemium"].map(i=><SelectItem key={i} value={i}>{i}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Budget</Label><Input placeholder="$ available runway"/></div>
            <div className="space-y-1.5"><Label>Country</Label><Input placeholder="e.g. United States"/></div>
          </div>
          <div className="space-y-1.5"><Label>Competitor Links</Label><Input placeholder="https://… (comma separated)"/></div>
          <div className="space-y-1.5"><Label>Additional Notes</Label><Textarea rows={2} placeholder="Anything else AI should know?"/></div>

          <label className="block border-2 border-dashed border-border rounded-xl p-6 text-center hover:border-primary/50 transition-colors cursor-pointer">
            <Upload className="h-5 w-5 mx-auto text-muted-foreground"/>
            <div className="mt-2 text-sm">Drop files or <span className="text-primary">browse</span></div>
            <div className="text-xs text-muted-foreground">Pitch deck, research, customer interviews · max 25MB</div>
            <input type="file" className="hidden"/>
          </label>

          <div className="flex items-center justify-between">
            <div className="text-xs text-muted-foreground">Draft auto-saved · just now</div>
            <Button type="submit" disabled={loading} className="bg-gradient-primary text-primary-foreground shadow-glow">
              {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin"/>Analyzing…</> : <>Run AI validation <ArrowRight className="ml-2 h-4 w-4"/></>}
            </Button>
          </div>
        </form>

        <aside className="space-y-4">
          <div className="glass rounded-2xl p-5 sticky top-20">
            <div className="text-xs text-muted-foreground">Live AI preview</div>
            <div className="mt-1 text-lg font-semibold flex items-center gap-2"><Sparkles className="h-4 w-4 text-primary"/> Validation score</div>
            <div className="mt-4 relative h-32 grid place-items-center">
              <svg viewBox="0 0 120 120" className="h-32 w-32 -rotate-90">
                <circle cx="60" cy="60" r="50" stroke="oklch(1 0 0 / 0.08)" strokeWidth="10" fill="none"/>
                <circle cx="60" cy="60" r="50" stroke="oklch(0.75 0.18 280)" strokeWidth="10" fill="none"
                  strokeDasharray={`${(score/100)*314} 314`} strokeLinecap="round"/>
              </svg>
              <div className="absolute text-3xl font-bold">{Math.round(score)}</div>
            </div>
            <div className="grid grid-cols-3 gap-2 mt-4 text-center">
              {[
                { i: TrendingUp, l: "Market", v: "Hot" },
                { i: Target, l: "ICP", v: "Clear" },
                { i: DollarSign, l: "Monet.", v: "OK" },
              ].map((s,i) => (
                <div key={i} className="glass rounded-lg p-2">
                  <s.i className="h-3.5 w-3.5 text-primary mx-auto"/>
                  <div className="text-[10px] text-muted-foreground mt-1">{s.l}</div>
                  <div className="text-xs font-medium">{s.v}</div>
                </div>
              ))}
            </div>
            <p className="mt-4 text-xs text-muted-foreground leading-relaxed">
              AI summary will appear here as you fill in the form. Add more detail to sharpen the score.
            </p>
          </div>
        </aside>
      </div>

      {done && (
        <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} className="space-y-6">
          <div className="glass-strong rounded-2xl p-6">
            <h2 className="text-xl font-semibold">Analysis complete</h2>
            <p className="text-sm text-muted-foreground">Here's a preview — open the full report for the deep dive.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { l: "Strengths", v: "Technical moat · Founder fit", c: "chart-3" },
              { l: "Weaknesses", v: "Unproven pricing", c: "chart-4" },
              { l: "Opportunities", v: "EU regulation tailwind", c: "chart-2" },
              { l: "Threats", v: "Incumbent w/ $40M Series B", c: "chart-5" },
            ].map((s) => (
              <div key={s.l} className="glass rounded-2xl p-5">
                <div className={`text-xs text-${s.c}`}>{s.l}</div>
                <div className="mt-2 text-sm">{s.v}</div>
              </div>
            ))}
          </div>
          <Link to="/dashboard/reports"><Button className="bg-gradient-primary text-primary-foreground">View full report <ArrowRight className="ml-2 h-4 w-4"/></Button></Link>
        </motion.div>
      )}
    </div>
  );
}
