import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Send, Plus, Sparkles, Paperclip, Bot, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { chatHistory, suggestedPrompts } from "@/lib/mock";
import { motion } from "framer-motion";

export const Route = createFileRoute("/dashboard/cofounder")({ component: CoFounder });

type Msg = { role: "user" | "assistant"; content: string };

function CoFounder() {
  const [msgs, setMsgs] = useState<Msg[]>([
    { role: "assistant", content: "Hey — I'm your AI co-founder. What are we figuring out today? You can ask me about pricing, GTM, fundraising, hiring, or stress-testing your idea." },
  ]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);

  const send = (text: string) => {
    if (!text.trim()) return;
    setMsgs((m) => [...m, { role: "user", content: text }]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setMsgs((m) => [...m, { role: "assistant", content: "Here's how I'd think about it:\n\n1. Start by isolating your most painful customer segment.\n2. Map their willingness-to-pay against your unit economics.\n3. Test a hybrid model — seat + usage — and instrument retention from day one.\n\nWant me to draft a one-page strategy memo around this?" }]);
    }, 900);
  };

  return (
    <div className="grid lg:grid-cols-[260px_1fr] gap-4 h-[calc(100vh-7rem)]">
      <aside className="hidden lg:flex flex-col glass rounded-2xl p-3">
        <Button className="bg-gradient-primary text-primary-foreground"><Plus className="mr-2 h-4 w-4"/>New chat</Button>
        <div className="mt-4 text-xs text-muted-foreground px-2">Recent</div>
        <div className="mt-2 space-y-1 overflow-y-auto">
          {chatHistory.map((c) => (
            <button key={c.id} className="w-full text-left px-3 py-2 rounded-lg hover:bg-sidebar-accent/60 text-sm">
              <div className="truncate">{c.title}</div>
              <div className="text-xs text-muted-foreground">{c.time}</div>
            </button>
          ))}
        </div>
      </aside>

      <div className="flex flex-col glass-strong rounded-2xl overflow-hidden">
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {msgs.map((m, i) => (
            <motion.div key={i} initial={{opacity:0,y:6}} animate={{opacity:1,y:0}} className={`flex gap-3 ${m.role==="user"?"justify-end":""}`}>
              {m.role==="assistant" && <div className="h-8 w-8 rounded-lg bg-gradient-primary grid place-items-center shrink-0"><Bot className="h-4 w-4 text-primary-foreground"/></div>}
              <div className={`max-w-2xl rounded-2xl px-4 py-3 text-sm whitespace-pre-wrap ${m.role==="user"?"bg-gradient-primary text-primary-foreground":"glass"}`}>
                {m.content}
              </div>
              {m.role==="user" && <div className="h-8 w-8 rounded-lg bg-secondary grid place-items-center shrink-0"><User className="h-4 w-4"/></div>}
            </motion.div>
          ))}
          {typing && (
            <div className="flex gap-3">
              <div className="h-8 w-8 rounded-lg bg-gradient-primary grid place-items-center"><Bot className="h-4 w-4 text-primary-foreground"/></div>
              <div className="glass rounded-2xl px-4 py-3 flex gap-1">
                <span className="h-2 w-2 bg-primary rounded-full animate-bounce"/>
                <span className="h-2 w-2 bg-primary rounded-full animate-bounce [animation-delay:120ms]"/>
                <span className="h-2 w-2 bg-primary rounded-full animate-bounce [animation-delay:240ms]"/>
              </div>
            </div>
          )}
        </div>
        <div className="border-t border-border/60 p-4 space-y-3">
          {msgs.length <= 1 && (
            <div className="flex flex-wrap gap-2">
              {suggestedPrompts.map((p) => (
                <button key={p} onClick={() => send(p)} className="glass rounded-full px-3 py-1.5 text-xs hover:border-primary/40">
                  <Sparkles className="inline h-3 w-3 mr-1 text-primary"/>{p}
                </button>
              ))}
            </div>
          )}
          <form onSubmit={(e)=>{e.preventDefault();send(input);}} className="flex items-center gap-2 glass rounded-xl pl-3 pr-1.5 py-1.5">
            <button type="button" className="text-muted-foreground hover:text-foreground"><Paperclip className="h-4 w-4"/></button>
            <Input value={input} onChange={(e)=>setInput(e.target.value)} placeholder="Ask your AI co-founder anything…" className="border-0 bg-transparent focus-visible:ring-0 shadow-none"/>
            <Button type="submit" size="icon" className="bg-gradient-primary text-primary-foreground h-9 w-9"><Send className="h-4 w-4"/></Button>
          </form>
        </div>
      </div>
    </div>
  );
}
