import { createFileRoute } from "@tanstack/react-router";
import { FileText, Download, Share2, ChevronDown, AlertTriangle, ShieldCheck, Lightbulb, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar, BarChart, Bar, XAxis, Tooltip } from "recharts";
import { swot } from "@/lib/mock";

export const Route = createFileRoute("/dashboard/reports")({ component: Reports });

const radar = [
  { axis: "Market", v: 86 }, { axis: "Team", v: 72 }, { axis: "Moat", v: 78 },
  { axis: "Monetization", v: 64 }, { axis: "Traction", v: 58 }, { axis: "Risk", v: 70 },
];
const comp = [
  { name: "You", score: 86 }, { name: "Notion AI", score: 92 }, { name: "Mem", score: 74 }, { name: "Reflect", score: 68 }, { name: "Tana", score: 71 },
];

function SectionCard({ icon: Icon, title, children, tone = "primary" }: { icon: any; title: string; children: React.ReactNode; tone?: string }) {
  return (
    <div className="glass rounded-2xl p-5">
      <div className="flex items-center gap-2 mb-3">
        <span className={`grid h-8 w-8 place-items-center rounded-lg bg-${tone}/20 border border-${tone}/30`}><Icon className={`h-4 w-4 text-${tone}`}/></span>
        <div className="font-semibold">{title}</div>
      </div>
      {children}
    </div>
  );
}

function Reports() {
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="text-xs text-muted-foreground">Report · #VR-00214</div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight mt-1">NeuroDesk — Investor Report</h1>
          <div className="flex gap-2 mt-2">
            <Badge variant="outline" className="border-primary/40 text-primary">Productivity</Badge>
            <Badge variant="outline" className="border-chart-3/40 text-chart-3">Score 86</Badge>
            <Badge variant="outline">Seed ready</Badge>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="glass"><Download className="mr-2 h-4 w-4"/>PDF</Button>
          <Button variant="outline" className="glass"><FileText className="mr-2 h-4 w-4"/>PPT</Button>
          <Button className="bg-gradient-primary text-primary-foreground"><Share2 className="mr-2 h-4 w-4"/>Share</Button>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 glass-strong rounded-2xl p-6">
          <div className="text-xs text-muted-foreground">Executive Summary</div>
          <h2 className="text-lg font-semibold mt-1">A keyboard-first AI workspace for engineering teams</h2>
          <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
            NeuroDesk addresses fragmented context across PR reviews, docs, and tickets by stitching a
            zero-click AI layer into developer workflows. The team shows strong founder–market fit and a
            credible technical moat, but monetization remains the biggest open question.
          </p>
        </div>
        <div className="glass rounded-2xl p-5">
          <div className="text-xs text-muted-foreground">Readiness radar</div>
          <div className="h-56">
            <ResponsiveContainer>
              <RadarChart data={radar}>
                <PolarGrid stroke="oklch(1 0 0 / 0.1)"/>
                <PolarAngleAxis dataKey="axis" tick={{ fill: "oklch(0.7 0.02 260)", fontSize: 11 }}/>
                <Radar dataKey="v" stroke="oklch(0.75 0.18 280)" fill="oklch(0.75 0.18 280)" fillOpacity={0.3}/>
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <SectionCard icon={ShieldCheck} title="Strengths" tone="chart-3">
          <ul className="text-sm space-y-1.5 text-muted-foreground list-disc pl-4">{swot.strengths.map(s=><li key={s}>{s}</li>)}</ul>
        </SectionCard>
        <SectionCard icon={AlertTriangle} title="Weaknesses" tone="chart-4">
          <ul className="text-sm space-y-1.5 text-muted-foreground list-disc pl-4">{swot.weaknesses.map(s=><li key={s}>{s}</li>)}</ul>
        </SectionCard>
        <SectionCard icon={Lightbulb} title="Opportunities" tone="chart-2">
          <ul className="text-sm space-y-1.5 text-muted-foreground list-disc pl-4">{swot.opportunities.map(s=><li key={s}>{s}</li>)}</ul>
        </SectionCard>
        <SectionCard icon={TrendingUp} title="Threats" tone="chart-5">
          <ul className="text-sm space-y-1.5 text-muted-foreground list-disc pl-4">{swot.threats.map(s=><li key={s}>{s}</li>)}</ul>
        </SectionCard>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="glass rounded-2xl p-5">
          <div className="font-semibold mb-3">Competitor benchmark</div>
          <div className="h-56">
            <ResponsiveContainer>
              <BarChart data={comp}>
                <XAxis dataKey="name" stroke="oklch(0.7 0.02 260)" fontSize={12}/>
                <Tooltip contentStyle={{ background: "oklch(0.2 0.022 270)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12 }}/>
                <Bar dataKey="score" radius={[8,8,0,0]} fill="oklch(0.75 0.18 280)"/>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="glass rounded-2xl p-5">
          <div className="font-semibold mb-3">Roadmap</div>
          <ol className="relative border-l border-border ml-3 space-y-5">
            {[
              { t: "Q1", l: "Closed beta · 25 design partners" },
              { t: "Q2", l: "Self-serve · usage-based pricing" },
              { t: "Q3", l: "Series Seed · $2.5M" },
              { t: "Q4", l: "Enterprise pilots · SOC2 Type I" },
            ].map((m,i) => (
              <li key={i} className="ml-4">
                <span className="absolute -left-1.5 h-3 w-3 rounded-full bg-gradient-primary shadow-glow"/>
                <div className="text-xs text-muted-foreground">{m.t}</div>
                <div className="text-sm">{m.l}</div>
              </li>
            ))}
          </ol>
        </div>
      </div>

      <Accordion type="multiple" className="glass rounded-2xl px-6">
        {[
          { t: "Market Opportunity", c: "TAM ~$4.2B with a SAM of $920M concentrated in mid-market dev teams." },
          { t: "Revenue Model", c: "Hybrid seat + usage with annual prepay. Projected ARPU $480/yr." },
          { t: "Risks", c: "Platform risk on OpenAI; mitigated via abstraction layer and OSS fallback." },
          { t: "AI Recommendations", c: "Tighten ICP, ship public changelog, recruit design hire." },
          { t: "Growth Strategy", c: "PLG funnel with developer-led virality + curated enterprise pilots." },
        ].map((s,i) => (
          <AccordionItem key={i} value={`s${i}`} className="border-border/60">
            <AccordionTrigger className="text-left">{s.t}</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">{s.c}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}
