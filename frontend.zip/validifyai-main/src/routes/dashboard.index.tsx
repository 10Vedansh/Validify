import { createFileRoute, Link } from "@tanstack/react-router";
import { Lightbulb, Gauge, Sparkles, TrendingUp, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";
import { StatCard } from "@/components/dashboard/StatCard";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell, Legend } from "recharts";
import { trendData, industries, validations, recommendations } from "@/lib/mock";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/dashboard/")({ component: Dashboard });

const COLORS = ["oklch(0.75 0.18 280)","oklch(0.72 0.18 200)","oklch(0.78 0.17 150)","oklch(0.80 0.18 70)","oklch(0.70 0.20 340)"];

function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Welcome back, Ada</h1>
          <p className="text-sm text-muted-foreground">Here's what's happening across your portfolio of ideas.</p>
        </div>
        <Link to="/dashboard/validate" className="inline-flex items-center gap-1 text-sm text-primary hover:underline">New validation <ArrowRight className="h-3.5 w-3.5"/></Link>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: Lightbulb, label: "Total Ideas", value: "24", delta: "+4 this wk" },
          { icon: Gauge, label: "Avg Validation Score", value: "78", delta: "+6%" },
          { icon: TrendingUp, label: "Investor Readiness", value: "A-", accent: "Seed ready" },
          { icon: Sparkles, label: "AI Suggestions", value: "412", delta: "+38" },
        ].map((s, i) => (
          <motion.div key={i} initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} transition={{delay:i*0.06}}>
            <StatCard {...s} />
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 glass rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-xs text-muted-foreground">Startup signal trends</div>
              <div className="text-lg font-semibold">Validation momentum</div>
            </div>
            <Badge variant="outline" className="border-primary/40 text-primary">Last 7 months</Badge>
          </div>
          <div className="h-72">
            <ResponsiveContainer>
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="d1" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="oklch(0.75 0.18 280)" stopOpacity={0.5}/><stop offset="100%" stopColor="oklch(0.75 0.18 280)" stopOpacity={0}/></linearGradient>
                  <linearGradient id="d2" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="oklch(0.72 0.18 200)" stopOpacity={0.4}/><stop offset="100%" stopColor="oklch(0.72 0.18 200)" stopOpacity={0}/></linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.06)"/>
                <XAxis dataKey="month" stroke="oklch(0.7 0.02 260)" fontSize={12}/>
                <YAxis stroke="oklch(0.7 0.02 260)" fontSize={12}/>
                <Tooltip contentStyle={{ background: "oklch(0.2 0.022 270)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12 }}/>
                <Area type="monotone" dataKey="ai" stroke="oklch(0.75 0.18 280)" fill="url(#d1)" strokeWidth={2}/>
                <Area type="monotone" dataKey="fintech" stroke="oklch(0.72 0.18 200)" fill="url(#d2)" strokeWidth={2}/>
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="glass rounded-2xl p-5">
          <div className="text-xs text-muted-foreground">Trending industries</div>
          <div className="text-lg font-semibold mb-2">Idea distribution</div>
          <div className="h-72">
            <ResponsiveContainer>
              <PieChart>
                <Pie data={industries} dataKey="value" innerRadius={55} outerRadius={90} paddingAngle={3}>
                  {industries.map((_,i) => <Cell key={i} fill={COLORS[i]}/>)}
                </Pie>
                <Tooltip contentStyle={{ background: "oklch(0.2 0.022 270)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12 }}/>
                <Legend wrapperStyle={{ fontSize: 12 }}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 glass rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="text-lg font-semibold">Recent validations</div>
            <Link to="/dashboard/reports" className="text-sm text-primary hover:underline">View all</Link>
          </div>
          <div className="divide-y divide-border/60">
            {validations.map((v) => (
              <Link key={v.name} to="/dashboard/reports" className="flex items-center gap-4 py-3 hover:bg-sidebar-accent/40 rounded-lg px-2 transition-colors">
                <div className="h-10 w-10 rounded-lg bg-gradient-primary/20 border border-primary/30 grid place-items-center text-sm font-semibold">{v.name[0]}</div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{v.name}</div>
                  <div className="text-xs text-muted-foreground">{v.industry}</div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="hidden sm:block w-28 h-1.5 rounded-full bg-secondary overflow-hidden">
                    <div className="h-full bg-gradient-primary" style={{ width: `${v.score}%` }}/>
                  </div>
                  <div className="text-sm font-semibold w-8 text-right">{v.score}</div>
                  <Badge variant="outline" className="hidden sm:inline-flex border-primary/30 text-primary">{v.status}</Badge>
                </div>
              </Link>
            ))}
          </div>
        </div>
        <div className="glass rounded-2xl p-5">
          <div className="text-lg font-semibold mb-3">AI Recommendations</div>
          <ul className="space-y-3">
            {recommendations.map((r,i) => (
              <li key={i} className="flex gap-3 text-sm">
                <Sparkles className="h-4 w-4 text-primary mt-0.5 shrink-0"/>
                <span className="text-muted-foreground">{r}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
